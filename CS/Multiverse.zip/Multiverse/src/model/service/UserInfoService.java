package model.service;

public class UserInfoService {
}
