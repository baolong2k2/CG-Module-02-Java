package model.exception;

public class InvalidChoiceException extends Exception{
    public InvalidChoiceException(String message) {
        super(message);
    }
}
